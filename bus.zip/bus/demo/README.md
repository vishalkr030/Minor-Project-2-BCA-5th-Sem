# Bus Booking

A Bus Seat Reservation System

## Getting Started

[Demo](https://james-muriithi.github.io/bus/index.html)


This is a simple bus booking project am working on currently.

## Screenshot
![Screen Shots](https://james-muriithi.github.io/bus/images/screenshot.png)







